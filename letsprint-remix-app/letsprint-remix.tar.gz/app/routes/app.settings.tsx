import { json, type LoaderFunctionArgs, type ActionFunctionArgs } from "@remix-run/node";
import { useLoaderData, useSubmit, Form } from "@remix-run/react";
import {
  Page,
  Layout,
  Card,
  FormLayout,
  TextField,
  Button,
  Banner,
  Select,
} from "@shopify/polaris";
import { authenticate } from "~/shopify.server";
import { useState } from "react";

export const loader = async ({ request }: LoaderFunctionArgs) => {
  const { session } = await authenticate.admin(request);
  
  // TODO: Load settings from database
  const settings = {
    businessName: "",
    gstin: "",
    address: "",
    city: "",
    state: "MH",
    pincode: "",
    phone: "",
    email: "",
    storeState: "MH",
  };

  return json({ settings, shop: session.shop });
};

export const action = async ({ request }: ActionFunctionArgs) => {
  const { session } = await authenticate.admin(request);
  const formData = await request.formData();

  // TODO: Save settings to database
  const settings = {
    businessName: formData.get("businessName"),
    gstin: formData.get("gstin"),
    address: formData.get("address"),
    city: formData.get("city"),
    state: formData.get("state"),
    pincode: formData.get("pincode"),
    phone: formData.get("phone"),
    email: formData.get("email"),
    storeState: formData.get("storeState"),
  };

  console.log("Saving settings:", settings);

  return json({ success: true, message: "Settings saved successfully" });
};

const INDIAN_STATES = [
  { label: "Andhra Pradesh", value: "AP" },
  { label: "Arunachal Pradesh", value: "AR" },
  { label: "Assam", value: "AS" },
  { label: "Bihar", value: "BR" },
  { label: "Chhattisgarh", value: "CG" },
  { label: "Goa", value: "GA" },
  { label: "Gujarat", value: "GJ" },
  { label: "Haryana", value: "HR" },
  { label: "Himachal Pradesh", value: "HP" },
  { label: "Jharkhand", value: "JH" },
  { label: "Karnataka", value: "KA" },
  { label: "Kerala", value: "KL" },
  { label: "Madhya Pradesh", value: "MP" },
  { label: "Maharashtra", value: "MH" },
  { label: "Manipur", value: "MN" },
  { label: "Meghalaya", value: "ML" },
  { label: "Mizoram", value: "MZ" },
  { label: "Nagaland", value: "NL" },
  { label: "Odisha", value: "OR" },
  { label: "Punjab", value: "PB" },
  { label: "Rajasthan", value: "RJ" },
  { label: "Sikkim", value: "SK" },
  { label: "Tamil Nadu", value: "TN" },
  { label: "Telangana", value: "TG" },
  { label: "Tripura", value: "TR" },
  { label: "Uttar Pradesh", value: "UP" },
  { label: "Uttarakhand", value: "UT" },
  { label: "West Bengal", value: "WB" },
  { label: "Delhi", value: "DL" },
];

export default function SettingsPage() {
  const { settings } = useLoaderData<typeof loader>();
  const submit = useSubmit();
  const [showSuccess, setShowSuccess] = useState(false);

  const handleSubmit = (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const formData = new FormData(event.currentTarget);
    submit(formData, { method: "post" });
    setShowSuccess(true);
    setTimeout(() => setShowSuccess(false), 3000);
  };

  return (
    <Page
      title="Settings"
      subtitle="Configure your business information and GST details"
      backAction={{ url: "/app" }}
    >
      <Layout>
        {showSuccess && (
          <Layout.Section>
            <Banner
              title="Settings saved successfully"
              tone="success"
              onDismiss={() => setShowSuccess(false)}
            />
          </Layout.Section>
        )}

        <Layout.Section>
          <Form onSubmit={handleSubmit}>
            <Card>
              <div style={{ padding: "16px" }}>
                <FormLayout>
                  <h3 style={{ fontWeight: "bold", marginBottom: "16px" }}>
                    Business Information
                  </h3>
                  <TextField
                    label="Business Name"
                    name="businessName"
                    defaultValue={settings.businessName}
                    autoComplete="off"
                    required
                  />
                  <TextField
                    label="GSTIN"
                    name="gstin"
                    defaultValue={settings.gstin}
                    autoComplete="off"
                    helpText="Your 15-digit GST Identification Number"
                    placeholder="22AAAAA0000A1Z5"
                    required
                  />
                  <TextField
                    label="Address"
                    name="address"
                    defaultValue={settings.address}
                    autoComplete="off"
                    multiline={3}
                    required
                  />
                  <FormLayout.Group>
                    <TextField
                      label="City"
                      name="city"
                      defaultValue={settings.city}
                      autoComplete="off"
                      required
                    />
                    <Select
                      label="State"
                      name="state"
                      options={INDIAN_STATES}
                      value={settings.state}
                      required
                    />
                  </FormLayout.Group>
                  <FormLayout.Group>
                    <TextField
                      label="Pincode"
                      name="pincode"
                      defaultValue={settings.pincode}
                      autoComplete="off"
                      type="text"
                      pattern="[0-9]{6}"
                      helpText="6-digit postal code"
                      required
                    />
                    <TextField
                      label="Phone"
                      name="phone"
                      defaultValue={settings.phone}
                      autoComplete="off"
                      type="tel"
                      required
                    />
                  </FormLayout.Group>
                  <TextField
                    label="Email"
                    name="email"
                    defaultValue={settings.email}
                    autoComplete="off"
                    type="email"
                    required
                  />
                </FormLayout>
              </div>
            </Card>

            <div style={{ marginTop: "16px" }}>
              <Card>
                <div style={{ padding: "16px" }}>
                  <FormLayout>
                    <h3 style={{ fontWeight: "bold", marginBottom: "16px" }}>
                      GST Configuration
                    </h3>
                    <Select
                      label="Store State"
                      name="storeState"
                      options={INDIAN_STATES}
                      value={settings.storeState}
                      helpText="The state where your business is registered. This is used to calculate CGST/SGST vs IGST."
                      required
                    />
                  </FormLayout>
                </div>
              </Card>
            </div>

            <div style={{ marginTop: "16px" }}>
              <Button variant="primary" submit>
                Save Settings
              </Button>
            </div>
          </Form>
        </Layout.Section>

        <Layout.Section variant="oneThird">
          <Card>
            <div style={{ padding: "16px" }}>
              <h3 style={{ fontWeight: "bold", marginBottom: "12px" }}>
                About GST Settings
              </h3>
              <p style={{ marginBottom: "12px" }}>
                Your business information will appear on all generated GST
                invoices.
              </p>
              <p style={{ marginBottom: "12px" }}>
                <strong>CGST/SGST:</strong> Applied when customer is in the same
                state as your store.
              </p>
              <p>
                <strong>IGST:</strong> Applied when customer is in a different
                state.
              </p>
            </div>
          </Card>
        </Layout.Section>
      </Layout>
    </Page>
  );
}
