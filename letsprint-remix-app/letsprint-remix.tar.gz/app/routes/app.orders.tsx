import { json, type LoaderFunctionArgs } from "@remix-run/node";
import { useLoaderData, Link } from "@remix-run/react";
import {
  Page,
  Layout,
  Card,
  DataTable,
  Badge,
  Button,
  TextField,
  Select,
  Stack,
  Filters,
} from "@shopify/polaris";
import { authenticate } from "~/shopify.server";
import { useState, useCallback } from "react";

export const loader = async ({ request }: LoaderFunctionArgs) => {
  const { admin, session } = await authenticate.admin(request);
  
  // Fetch orders from Shopify
  const response = await admin.graphql(
    `#graphql
      query getOrders($first: Int!) {
        orders(first: $first, sortKey: CREATED_AT, reverse: true) {
          edges {
            node {
              id
              name
              createdAt
              displayFinancialStatus
              displayFulfillmentStatus
              totalPriceSet {
                shopMoney {
                  amount
                  currencyCode
                }
              }
              customer {
                firstName
                lastName
                email
              }
              shippingAddress {
                provinceCode
                province
                city
                country
              }
              lineItems(first: 10) {
                edges {
                  node {
                    id
                    name
                    quantity
                    originalUnitPriceSet {
                      shopMoney {
                        amount
                        currencyCode
                      }
                    }
                  }
                }
              }
            }
          }
          pageInfo {
            hasNextPage
            hasPreviousPage
          }
        }
      }
    `,
    {
      variables: {
        first: 50,
      },
    }
  );

  const responseJson = await response.json();
  const orders = responseJson.data?.orders?.edges || [];

  return json({
    orders: orders.map((edge: any) => edge.node),
    shop: session.shop,
  });
};

export default function OrdersPage() {
  const { orders, shop } = useLoaderData<typeof loader>();
  const [searchValue, setSearchValue] = useState("");
  const [statusFilter, setStatusFilter] = useState<string | null>(null);

  const handleSearchChange = useCallback((value: string) => {
    setSearchValue(value);
  }, []);

  const handleStatusFilterChange = useCallback((value: string) => {
    setStatusFilter(value === "all" ? null : value);
  }, []);

  const handleSearchClear = useCallback(() => {
    setSearchValue("");
  }, []);

  // Filter orders based on search and status
  const filteredOrders = orders.filter((order: any) => {
    const matchesSearch =
      !searchValue ||
      order.name.toLowerCase().includes(searchValue.toLowerCase()) ||
      order.customer?.email?.toLowerCase().includes(searchValue.toLowerCase());

    const matchesStatus =
      !statusFilter || order.displayFinancialStatus === statusFilter;

    return matchesSearch && matchesStatus;
  });

  // Prepare data for DataTable
  const rows = filteredOrders.map((order: any) => [
    order.name,
    new Date(order.createdAt).toLocaleDateString(),
    order.customer
      ? `${order.customer.firstName} ${order.customer.lastName}`
      : "Guest",
    order.shippingAddress?.province || "N/A",
    `₹${parseFloat(order.totalPriceSet.shopMoney.amount).toFixed(2)}`,
    <Badge
      key={order.id}
      tone={
        order.displayFinancialStatus === "PAID"
          ? "success"
          : order.displayFinancialStatus === "PENDING"
          ? "attention"
          : "critical"
      }
    >
      {order.displayFinancialStatus}
    </Badge>,
    <Badge
      key={`fulfillment-${order.id}`}
      tone={
        order.displayFulfillmentStatus === "FULFILLED"
          ? "success"
          : order.displayFulfillmentStatus === "UNFULFILLED"
          ? "warning"
          : "info"
      }
    >
      {order.displayFulfillmentStatus || "Unfulfilled"}
    </Badge>,
    <Stack key={`actions-${order.id}`} alignment="center">
      <Button
        size="slim"
        url={`/app/orders/${order.id.split("/").pop()}`}
      >
        View
      </Button>
      <Button
        size="slim"
        variant="primary"
        url={`/app/orders/${order.id.split("/").pop()}/invoice`}
      >
        Generate Invoice
      </Button>
    </Stack>,
  ]);

  return (
    <Page
      title="Orders"
      subtitle="Manage and generate GST invoices for your orders"
      primaryAction={{
        content: "Bulk Actions",
        url: "/app/bulk-print",
      }}
    >
      <Layout>
        <Layout.Section>
          <Card>
            <div style={{ padding: "16px" }}>
              <Stack vertical>
                <TextField
                  label="Search orders"
                  value={searchValue}
                  onChange={handleSearchChange}
                  placeholder="Search by order number or customer email"
                  clearButton
                  onClearButtonClick={handleSearchClear}
                  autoComplete="off"
                />
                <Select
                  label="Filter by payment status"
                  options={[
                    { label: "All", value: "all" },
                    { label: "Paid", value: "PAID" },
                    { label: "Pending", value: "PENDING" },
                    { label: "Refunded", value: "REFUNDED" },
                  ]}
                  onChange={handleStatusFilterChange}
                  value={statusFilter || "all"}
                />
              </Stack>
            </div>
            <DataTable
              columnContentTypes={[
                "text",
                "text",
                "text",
                "text",
                "numeric",
                "text",
                "text",
                "text",
              ]}
              headings={[
                "Order",
                "Date",
                "Customer",
                "State",
                "Total",
                "Payment",
                "Fulfillment",
                "Actions",
              ]}
              rows={rows}
              footerContent={`Showing ${filteredOrders.length} of ${orders.length} orders`}
            />
          </Card>
        </Layout.Section>

        <Layout.Section variant="oneThird">
          <Card>
            <div style={{ padding: "16px" }}>
              <Stack vertical spacing="tight">
                <h3 style={{ fontWeight: "bold" }}>Quick Stats</h3>
                <p>Total Orders: {orders.length}</p>
                <p>
                  Paid Orders:{" "}
                  {
                    orders.filter(
                      (o: any) => o.displayFinancialStatus === "PAID"
                    ).length
                  }
                </p>
                <p>
                  Fulfilled:{" "}
                  {
                    orders.filter(
                      (o: any) => o.displayFulfillmentStatus === "FULFILLED"
                    ).length
                  }
                </p>
              </Stack>
            </div>
          </Card>
        </Layout.Section>
      </Layout>
    </Page>
  );
}
