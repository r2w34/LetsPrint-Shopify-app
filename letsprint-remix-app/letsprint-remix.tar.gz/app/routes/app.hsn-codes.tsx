import { json, type LoaderFunctionArgs, type ActionFunctionArgs } from "@remix-run/node";
import { useLoaderData, useSubmit, Form } from "@remix-run/react";
import {
  Page,
  Layout,
  Card,
  DataTable,
  Button,
  TextField,
  Modal,
  FormLayout,
  Banner,
} from "@shopify/polaris";
import { authenticate } from "~/shopify.server";
import { useState, useCallback } from "react";

export const loader = async ({ request }: LoaderFunctionArgs) => {
  const { admin, session } = await authenticate.admin(request);

  // Fetch products
  const response = await admin.graphql(
    `#graphql
      query getProducts($first: Int!) {
        products(first: $first) {
          edges {
            node {
              id
              title
              status
              totalInventory
              metafields(first: 5, namespace: "custom") {
                edges {
                  node {
                    key
                    value
                  }
                }
              }
            }
          }
        }
      }
    `,
    {
      variables: {
        first: 50,
      },
    }
  );

  const responseJson = await response.json();
  const products = responseJson.data?.products?.edges || [];

  return json({
    products: products.map((edge: any) => {
      const product = edge.node;
      const hsnMetafield = product.metafields.edges.find(
        (mf: any) => mf.node.key === "hsn_code"
      );
      return {
        ...product,
        hsnCode: hsnMetafield?.node.value || "",
      };
    }),
    shop: session.shop,
  });
};

export const action = async ({ request }: ActionFunctionArgs) => {
  const { admin, session } = await authenticate.admin(request);
  const formData = await request.formData();
  const action = formData.get("action");

  if (action === "update_hsn") {
    const productId = formData.get("productId");
    const hsnCode = formData.get("hsnCode");

    // Update product metafield
    const mutation = await admin.graphql(
      `#graphql
        mutation updateProductMetafield($input: ProductInput!) {
          productUpdate(input: $input) {
            product {
              id
              metafields(first: 5, namespace: "custom") {
                edges {
                  node {
                    key
                    value
                  }
                }
              }
            }
            userErrors {
              field
              message
            }
          }
        }
      `,
      {
        variables: {
          input: {
            id: productId,
            metafields: [
              {
                namespace: "custom",
                key: "hsn_code",
                value: hsnCode as string,
                type: "single_line_text_field",
              },
            ],
          },
        },
      }
    );

    const result = await mutation.json();

    if (result.data?.productUpdate?.userErrors?.length > 0) {
      return json({
        success: false,
        errors: result.data.productUpdate.userErrors,
      });
    }

    return json({ success: true, message: "HSN code updated successfully" });
  }

  return json({ success: false, message: "Invalid action" });
};

// Common HSN codes for Indian e-commerce
const COMMON_HSN_CODES = [
  { code: "6109", description: "T-shirts, vests and similar articles, knitted" },
  { code: "6204", description: "Women's suits, trousers, skirts" },
  { code: "6203", description: "Men's suits, trousers, shirts" },
  { code: "6402", description: "Footwear - Sports/casual" },
  { code: "4202", description: "Bags, backpacks, purses" },
  { code: "7113", description: "Jewellery" },
  { code: "3304", description: "Cosmetics, beauty products" },
  { code: "8517", description: "Mobile phones and accessories" },
  { code: "9018", description: "Medical equipment" },
  { code: "3926", description: "Plastic products" },
];

export default function HSNCodesPage() {
  const { products, shop } = useLoaderData<typeof loader>();
  const submit = useSubmit();
  const [selectedProduct, setSelectedProduct] = useState<any>(null);
  const [hsnCode, setHsnCode] = useState("");
  const [showSuccess, setShowSuccess] = useState(false);
  const [searchValue, setSearchValue] = useState("");

  const handleOpenModal = useCallback((product: any) => {
    setSelectedProduct(product);
    setHsnCode(product.hsnCode || "");
  }, []);

  const handleCloseModal = useCallback(() => {
    setSelectedProduct(null);
    setHsnCode("");
  }, []);

  const handleSaveHSN = useCallback(() => {
    const formData = new FormData();
    formData.append("action", "update_hsn");
    formData.append("productId", selectedProduct.id);
    formData.append("hsnCode", hsnCode);
    submit(formData, { method: "post" });
    handleCloseModal();
    setShowSuccess(true);
    setTimeout(() => setShowSuccess(false), 3000);
  }, [selectedProduct, hsnCode, submit, handleCloseModal]);

  // Filter products
  const filteredProducts = products.filter((product: any) =>
    product.title.toLowerCase().includes(searchValue.toLowerCase())
  );

  const rows = filteredProducts.map((product: any) => [
    product.title,
    product.hsnCode || "Not set",
    product.status,
    <Button
      key={product.id}
      size="slim"
      onClick={() => handleOpenModal(product)}
    >
      {product.hsnCode ? "Edit" : "Add"} HSN Code
    </Button>,
  ]);

  return (
    <Page
      title="HSN Code Management"
      subtitle="Assign HSN codes to products for GST compliance"
      backAction={{ url: "/app" }}
    >
      <Layout>
        {showSuccess && (
          <Layout.Section>
            <Banner
              title="HSN code updated successfully"
              tone="success"
              onDismiss={() => setShowSuccess(false)}
            />
          </Layout.Section>
        )}

        <Layout.Section>
          <Card>
            <div style={{ padding: "16px" }}>
              <TextField
                label="Search products"
                value={searchValue}
                onChange={setSearchValue}
                placeholder="Search by product name"
                clearButton
                onClearButtonClick={() => setSearchValue("")}
                autoComplete="off"
              />
            </div>
            <DataTable
              columnContentTypes={["text", "text", "text", "text"]}
              headings={["Product", "HSN Code", "Status", "Actions"]}
              rows={rows}
              footerContent={`Showing ${filteredProducts.length} of ${products.length} products`}
            />
          </Card>
        </Layout.Section>

        <Layout.Section variant="oneThird">
          <Card>
            <div style={{ padding: "16px" }}>
              <h3 style={{ fontWeight: "bold", marginBottom: "12px" }}>
                Common HSN Codes
              </h3>
              {COMMON_HSN_CODES.map((item) => (
                <div
                  key={item.code}
                  style={{
                    marginBottom: "8px",
                    padding: "8px",
                    border: "1px solid #e1e3e5",
                    borderRadius: "4px",
                  }}
                >
                  <strong>{item.code}</strong>
                  <br />
                  <small>{item.description}</small>
                </div>
              ))}
            </div>
          </Card>

          <div style={{ marginTop: "16px" }}>
            <Card>
              <div style={{ padding: "16px" }}>
                <h3 style={{ fontWeight: "bold", marginBottom: "12px" }}>
                  About HSN Codes
                </h3>
                <p style={{ marginBottom: "12px" }}>
                  HSN (Harmonized System of Nomenclature) codes are used to
                  classify products for GST purposes.
                </p>
                <p>
                  Each product should have the appropriate HSN code assigned for
                  accurate tax calculation and invoice generation.
                </p>
              </div>
            </Card>
          </div>
        </Layout.Section>
      </Layout>

      <Modal
        open={selectedProduct !== null}
        onClose={handleCloseModal}
        title={`Edit HSN Code: ${selectedProduct?.title}`}
        primaryAction={{
          content: "Save",
          onAction: handleSaveHSN,
        }}
        secondaryActions={[
          {
            content: "Cancel",
            onAction: handleCloseModal,
          },
        ]}
      >
        <Modal.Section>
          <FormLayout>
            <TextField
              label="HSN Code"
              value={hsnCode}
              onChange={setHsnCode}
              autoComplete="off"
              helpText="Enter 4, 6, or 8 digit HSN code"
              placeholder="e.g., 6109"
            />
            <div>
              <p style={{ fontWeight: "bold", marginBottom: "8px" }}>
                Suggested codes:
              </p>
              {COMMON_HSN_CODES.slice(0, 5).map((item) => (
                <Button
                  key={item.code}
                  size="slim"
                  onClick={() => setHsnCode(item.code)}
                  style={{ marginRight: "8px", marginBottom: "8px" }}
                >
                  {item.code} - {item.description}
                </Button>
              ))}
            </div>
          </FormLayout>
        </Modal.Section>
      </Modal>
    </Page>
  );
}
